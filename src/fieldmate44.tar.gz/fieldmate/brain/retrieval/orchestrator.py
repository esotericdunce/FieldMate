from __future__ import annotations

import asyncio
import time
from dataclasses import dataclass
from typing import Any

from fieldmate.brain.qdrant.repository import (
    QdrantMemoryRepository,
)
from fieldmate.brain.state.models import DiagnosticState

from .context import (
    DiagnosticContext,
    context_from_evidence,
)
from .context_intelligence import (
    ContextIntelligence,
)
from .evidence import (
    normalize_evidence,
)
from .planner import (
    RetrievalMode,
    RetrievalPlan,
    plan_retrieval,
)


# ============================================================
# RESULT
# ============================================================


@dataclass(frozen=True)
class RetrievalResult:
    """
    Complete result of one retrieval operation.

    The Brain receives this object rather than dealing directly
    with Qdrant.
    """

    context: DiagnosticContext
    plan: RetrievalPlan
    latency_ms: float

    timed_out: bool = False
    prefetched: bool = False


# ============================================================
# PREFETCH ENTRY
# ============================================================


@dataclass
class _PrefetchEntry:
    query: str
    task: asyncio.Task[Any]
    created_at: float


# ============================================================
# ORCHESTRATOR
# ============================================================


class RetrievalOrchestrator:
    """
    Adaptive, bounded retrieval coordinator.

    Architecture:

        query
          |
          v
        Planner
          |
          +---- dense
          +---- sparse
          +---- hybrid
          |
          v
        Qdrant
          |
          v
        raw points
          |
          v
        Evidence normalization
          |
          v
        Context Intelligence
          |
          v
        DiagnosticContext
          |
          v
        Brain


    Guarantees:

    - retrieval never decides diagnosis
    - retrieval never modifies diagnostic state
    - hot-path retrieval is time bounded
    - speculative prefetch never blocks the hot path
    - contradictory evidence is preserved
    - raw Qdrant representations do not leak into Brain
    - Qdrant failures degrade into an empty context
    - stale prefetches are discarded
    """

    def __init__(
        self,
        repository: QdrantMemoryRepository,
        *,
        timeout_ms: int = 900,
        prefetch_timeout_ms: int = 3000,
        prefetch_ttl_ms: int = 5000,
        context_intelligence: ContextIntelligence | None = None,
    ) -> None:

        if timeout_ms <= 0:
            raise ValueError(
                "timeout_ms must be > 0"
            )

        if prefetch_timeout_ms <= 0:
            raise ValueError(
                "prefetch_timeout_ms must be > 0"
            )

        if prefetch_ttl_ms <= 0:
            raise ValueError(
                "prefetch_ttl_ms must be > 0"
            )

        self.repository = repository

        self.timeout_seconds = (
            timeout_ms / 1000.0
        )

        self.prefetch_timeout_seconds = (
            prefetch_timeout_ms / 1000.0
        )

        self.prefetch_ttl_seconds = (
            prefetch_ttl_ms / 1000.0
        )

        self.context_intelligence = (
            context_intelligence
            or ContextIntelligence()
        )

        self._prefetch: dict[
            str,
            _PrefetchEntry,
        ] = {}

        self._lock = asyncio.Lock()

        self._closed = False

    # ========================================================
    # MAIN RETRIEVAL
    # ========================================================

    async def retrieve(
        self,
        query: str,
        *,
        state: DiagnosticState | None = None,
        equipment_model: str | None = None,
        equipment_family: str | None = None,
        equipment_serial: str | None = None,
        system: str | None = None,
        subsystem: str | None = None,
        component: str | None = None,
        fault_code: str | None = None,
        memory_types: list[str] | None = None,
        statuses: list[str] | None = None,
        scope: str | None = None,
        owner_id: str | None = None,
        verified_only: bool = False,
        limit: int = 8,
    ) -> RetrievalResult:
        """
        Perform one bounded retrieval operation.

        `state` is optional for compatibility with callers that
        only have structured equipment/filter information.

        When state is supplied, ContextIntelligence performs
        state-aware evidence ranking and contradiction handling.
        """

        started = time.perf_counter()

        normalized_query = (
            " ".join(
                query.strip().split()
            )
        )

        if not normalized_query:
            return RetrievalResult(
                context=DiagnosticContext(
                    memories=()
                ),
                plan=plan_retrieval(""),
                latency_ms=0.0,
            )

        if limit < 1:
            limit = 1

        # ----------------------------------------------------
        # PLAN
        # ----------------------------------------------------

        plan = plan_retrieval(
            normalized_query,
            has_equipment_context=(
                equipment_model is not None
                or equipment_family is not None
                or equipment_serial is not None
            ),
            has_fault_context=(
                fault_code is not None
            ),
        )

        # ----------------------------------------------------
        # BUILD FILTER
        # ----------------------------------------------------

        query_filter = (
            self.repository.build_filter(
                equipment_model=equipment_model,
                equipment_family=equipment_family,
                equipment_serial=equipment_serial,
                system=system,
                subsystem=subsystem,
                component=component,
                fault_code=fault_code,
                memory_types=memory_types,
                statuses=statuses,
                scope=scope,
                owner_id=owner_id,
                verified_only=verified_only,
            )
        )

        # ----------------------------------------------------
        # PREFETCH HIT
        # ----------------------------------------------------

        cache_key = self._cache_key(
            query=normalized_query,
            plan=plan,
            equipment_model=equipment_model,
            equipment_family=equipment_family,
            equipment_serial=equipment_serial,
            system=system,
            subsystem=subsystem,
            component=component,
            fault_code=fault_code,
            memory_types=memory_types,
            statuses=statuses,
            scope=scope,
            owner_id=owner_id,
            verified_only=verified_only,
        )

        prefetched = (
            await self._consume_completed_prefetch(
                cache_key
            )
        )

        if prefetched is not None:
            context = self._build_context(
                prefetched,
                state=state,
                query=normalized_query,
                retrieval_mode=plan.mode.value,
                limit=limit,
                prefetched=True,
            )

            return RetrievalResult(
                context=context,
                plan=plan,
                latency_ms=(
                    time.perf_counter()
                    - started
                ) * 1000.0,
                prefetched=True,
            )

        # ----------------------------------------------------
        # NORMAL BOUNDED RETRIEVAL
        # ----------------------------------------------------

        try:
            points = await asyncio.wait_for(
                self._execute(
                    plan=plan,
                    query=normalized_query,
                    query_filter=query_filter,
                    limit=limit,
                ),
                timeout=self.timeout_seconds,
            )

        except asyncio.TimeoutError:

            elapsed = (
                time.perf_counter()
                - started
            ) * 1000.0

            return RetrievalResult(
                context=DiagnosticContext(
                    memories=()
                ),
                plan=plan,
                latency_ms=elapsed,
                timed_out=True,
            )

        except asyncio.CancelledError:
            raise

        except Exception:
            # Retrieval failure must not crash the voice
            # conversation.
            #
            # The Brain can continue without historical memory.
            elapsed = (
                time.perf_counter()
                - started
            ) * 1000.0

            return RetrievalResult(
                context=DiagnosticContext(
                    memories=()
                ),
                plan=plan,
                latency_ms=elapsed,
            )

        # ----------------------------------------------------
        # BUILD DOMAIN CONTEXT
        # ----------------------------------------------------

        context = self._build_context(
            points,
            state=state,
            query=normalized_query,
            retrieval_mode=plan.mode.value,
            limit=limit,
        )

        elapsed = (
            time.perf_counter()
            - started
        ) * 1000.0

        return RetrievalResult(
            context=context,
            plan=plan,
            latency_ms=elapsed,
        )

    # ========================================================
    # CONTEXT CONSTRUCTION
    # ========================================================

    def _build_context(
        self,
        points: Any,
        *,
        state: DiagnosticState | None,
        query: str,
        retrieval_mode: str,
        limit: int,
        prefetched: bool = False,
        timed_out: bool = False,
    ) -> DiagnosticContext:
        """
        Convert Qdrant output into the application's domain
        context.

        Pipeline:

            Qdrant points
                ↓
            Evidence
                ↓
            ContextIntelligence
                ↓
            DiagnosticContext
        """

        evidence = normalize_evidence(
            list(points or []),
            state=state,
            retrieval_mode=retrieval_mode,
        )

        if not evidence:
            return DiagnosticContext(
                memories=()
            )

        # ----------------------------------------------------
        # State-aware context intelligence.
        # ----------------------------------------------------

        if state is not None:

            return (
                self.context_intelligence
                .build_diagnostic_context(
                    evidence,
                    state,
                    query=query,
                    retrieval_mode=retrieval_mode,
                    prefetched=prefetched,
                    timed_out=timed_out,
                )
            )

        # ----------------------------------------------------
        # Compatibility path.
        #
        # Some callers may not have DiagnosticState yet.
        # Do not fabricate diagnostic state merely for
        # retrieval.
        # ----------------------------------------------------

        limited = list(
            evidence[:limit]
        )

        return context_from_evidence(
            limited,
            query=query,
            retrieval_mode=retrieval_mode,
            max_memories=limit,
            prefetched=prefetched,
            timed_out=timed_out,
        )

    # ========================================================
    # SPECULATIVE PREFETCH
    # ========================================================

    async def prefetch(
        self,
        query: str,
        *,
        equipment_model: str | None = None,
        equipment_family: str | None = None,
        equipment_serial: str | None = None,
        system: str | None = None,
        subsystem: str | None = None,
        component: str | None = None,
        fault_code: str | None = None,
        memory_types: list[str] | None = None,
        statuses: list[str] | None = None,
        scope: str | None = None,
        owner_id: str | None = None,
        verified_only: bool = False,
        limit: int = 8,
    ) -> None:
        """
        Start speculative retrieval.

        This method intentionally does not await the actual
        Qdrant request.

        The next retrieve() call may consume the completed
        result if its cache key matches.
        """

        if self._closed:
            return

        normalized_query = (
            " ".join(
                query.strip().split()
            )
        )

        if not normalized_query:
            return

        if limit < 1:
            limit = 1

        plan = plan_retrieval(
            normalized_query,
            has_equipment_context=(
                equipment_model is not None
                or equipment_family is not None
                or equipment_serial is not None
            ),
            has_fault_context=(
                fault_code is not None
            ),
        )

        query_filter = (
            self.repository.build_filter(
                equipment_model=equipment_model,
                equipment_family=equipment_family,
                equipment_serial=equipment_serial,
                system=system,
                subsystem=subsystem,
                component=component,
                fault_code=fault_code,
                memory_types=memory_types,
                statuses=statuses,
                scope=scope,
                owner_id=owner_id,
                verified_only=verified_only,
            )
        )

        cache_key = self._cache_key(
            query=normalized_query,
            plan=plan,
            equipment_model=equipment_model,
            equipment_family=equipment_family,
            equipment_serial=equipment_serial,
            system=system,
            subsystem=subsystem,
            component=component,
            fault_code=fault_code,
            memory_types=memory_types,
            statuses=statuses,
            scope=scope,
            owner_id=owner_id,
            verified_only=verified_only,
        )

        async with self._lock:

            existing = self._prefetch.get(
                cache_key
            )

            if existing is not None:

                if not existing.task.done():
                    return

                self._prefetch.pop(
                    cache_key,
                    None,
                )

            task = asyncio.create_task(
                self._prefetch_execute(
                    plan=plan,
                    query=normalized_query,
                    query_filter=query_filter,
                    limit=limit,
                )
            )

            self._prefetch[
                cache_key
            ] = _PrefetchEntry(
                query=normalized_query,
                task=task,
                created_at=time.perf_counter(),
            )

    # ========================================================
    # PREFETCH EXECUTION
    # ========================================================

    async def _prefetch_execute(
        self,
        *,
        plan: RetrievalPlan,
        query: str,
        query_filter: Any,
        limit: int,
    ) -> list[Any] | None:
        """
        Execute speculative retrieval under its own timeout.

        Errors are swallowed because prefetch is opportunistic.
        """

        try:

            result = await asyncio.wait_for(
                self._execute(
                    plan=plan,
                    query=query,
                    query_filter=query_filter,
                    limit=limit,
                ),
                timeout=(
                    self.prefetch_timeout_seconds
                ),
            )

            return result

        except asyncio.CancelledError:
            raise

        except Exception:
            return None

    # ========================================================
    # PREFETCH CONSUMPTION
    # ========================================================

    async def _consume_completed_prefetch(
        self,
        cache_key: str,
    ) -> list[Any] | None:
        """
        Consume a completed speculative retrieval.

        Critical invariant:

            NEVER wait for a still-running prefetch.

        If it isn't already complete, normal retrieval proceeds.
        """

        async with self._lock:

            entry = self._prefetch.get(
                cache_key
            )

            if entry is None:
                return None

            age = (
                time.perf_counter()
                - entry.created_at
            )

            # ------------------------------------------------
            # STALE
            # ------------------------------------------------

            if (
                age
                > self.prefetch_ttl_seconds
            ):

                if not entry.task.done():
                    entry.task.cancel()

                self._prefetch.pop(
                    cache_key,
                    None,
                )

                return None

            # ------------------------------------------------
            # STILL RUNNING
            # ------------------------------------------------

            if not entry.task.done():
                return None

            self._prefetch.pop(
                cache_key,
                None,
            )

        # ----------------------------------------------------
        # Retrieve result outside lock.
        # ----------------------------------------------------

        try:
            result = entry.task.result()

        except (
            asyncio.CancelledError,
            Exception,
        ):
            return None

        if not result:
            return None

        return result

    # ========================================================
    # EXECUTION
    # ========================================================

    async def _execute(
        self,
        *,
        plan: RetrievalPlan,
        query: str,
        query_filter: Any,
        limit: int,
    ) -> list[Any]:
        """
        Execute exactly one retrieval strategy.

        Strategy selection belongs exclusively to Planner.
        """

        if plan.mode == RetrievalMode.SPARSE:

            result = (
                await self.repository.search_sparse(
                    query,
                    limit=limit,
                    query_filter=query_filter,
                )
            )

        elif plan.mode == RetrievalMode.HYBRID:

            result = (
                await self.repository.search_hybrid(
                    query,
                    limit=limit,
                    query_filter=query_filter,
                )
            )

        else:

            result = (
                await self.repository.search_dense(
                    query,
                    limit=limit,
                    query_filter=query_filter,
                )
            )

        return list(result or [])

    # ========================================================
    # CACHE KEY
    # ========================================================

    @staticmethod
    def _cache_key(
        *,
        query: str,
        plan: RetrievalPlan,
        equipment_model: str | None,
        equipment_family: str | None,
        equipment_serial: str | None,
        system: str | None,
        subsystem: str | None,
        component: str | None,
        fault_code: str | None,
        memory_types: list[str] | None,
        statuses: list[str] | None,
        scope: str | None,
        owner_id: str | None,
        verified_only: bool,
    ) -> str:
        """
        Build a deterministic cache key.

        Every retrieval-affecting filter is included.

        This prevents a dangerous situation where:

            same query + different equipment

        accidentally consumes the wrong prefetched result.
        """

        normalized_query = (
            " ".join(
                query.lower().split()
            )
        )

        def normalize_list(
            values: list[str] | None,
        ) -> str:
            if not values:
                return ""

            return ",".join(
                sorted(
                    str(value).strip().lower()
                    for value in values
                    if str(value).strip()
                )
            )

        parts = (
            plan.mode.value,
            normalized_query,
            (
                equipment_model
                or ""
            ).strip().lower(),
            (
                equipment_family
                or ""
            ).strip().lower(),
            (
                equipment_serial
                or ""
            ).strip().lower(),
            (
                system
                or ""
            ).strip().lower(),
            (
                subsystem
                or ""
            ).strip().lower(),
            (
                component
                or ""
            ).strip().lower(),
            (
                fault_code
                or ""
            ).strip().lower(),
            normalize_list(
                memory_types
            ),
            normalize_list(
                statuses
            ),
            (
                scope
                or ""
            ).strip().lower(),
            (
                owner_id
                or ""
            ).strip().lower(),
            "verified" if verified_only else "any",
        )

        return "|".join(parts)

    # ========================================================
    # SHUTDOWN
    # ========================================================

    async def close(self) -> None:
        """
        Cancel outstanding speculative retrievals.

        This method is safe to call more than once.
        """

        if self._closed:
            return

        self._closed = True

        async with self._lock:

            tasks = [
                entry.task
                for entry in self._prefetch.values()
                if not entry.task.done()
            ]

            self._prefetch.clear()

        if tasks:

            for task in tasks:
                task.cancel()

            await asyncio.gather(
                *tasks,
                return_exceptions=True,
            )